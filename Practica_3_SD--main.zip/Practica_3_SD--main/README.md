# Practica_3_SD-
Practica 3 de Sistemas Distribuidos Rand y Calculadora
Integrantes: 
Lopez Lopez Arturo 
Olivares Piña Usiel Alonso 
Santana Islas Gerardo Leonardo
